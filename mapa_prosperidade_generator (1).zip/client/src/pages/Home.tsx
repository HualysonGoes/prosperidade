import { MysticBackground } from "@/components/MysticBackground";
import { MysticCard } from "@/components/MysticCard";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { usePdfDownload } from "@/hooks/use-pdf-download";
import { gerarMapaProsperidade, MapaData } from "@/lib/mapa-engine";
import { motion } from "framer-motion";
import { ArrowRight, BookOpen, Calendar, Compass, Crown, Download, Gem, Heart, Lightbulb, Lock, ScrollText, Sparkles, Star } from "lucide-react";
import { useState } from "react";

export default function Home() {
  const { downloadPdf, isGenerating } = usePdfDownload();
  const [nome, setNome] = useState("");
  const [dataNascimento, setDataNascimento] = useState("");
  const [mapa, setMapa] = useState<MapaData | null>(null);
  const [loading, setLoading] = useState(false);
  const [step, setStep] = useState<'form' | 'result'>('form');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!nome || !dataNascimento) return;

    setLoading(true);
    
    // Simulate a ritualistic delay
    setTimeout(() => {
      const resultado = gerarMapaProsperidade(nome, dataNascimento);
      setMapa(resultado);
      setStep('result');
      setLoading(false);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }, 2000);
  };

  const resetForm = () => {
    setStep('form');
    setMapa(null);
    setNome("");
    setDataNascimento("");
  };

  return (
    <div className="min-h-screen flex flex-col relative text-foreground font-sans selection:bg-primary/30 selection:text-primary-foreground">
      <MysticBackground />
      
      <main className="flex-grow container py-12 md:py-20 px-4 md:px-8 max-w-5xl mx-auto z-10">
        
        {/* Header */}
        <motion.div 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1 }}
          className="text-center mb-16 space-y-4"
        >
          <div className="inline-block mb-2">
            <Sparkles className="w-8 h-8 text-primary mx-auto animate-pulse" />
          </div>
          <h1 className="font-cinzel text-4xl md:text-6xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-primary via-white to-primary tracking-wider drop-shadow-[0_0_15px_rgba(212,175,55,0.3)]">
            MAPA DA PROSPERIDADE
          </h1>
          <p className="font-cormorant text-xl md:text-2xl text-muted-foreground max-w-2xl mx-auto italic">
            "Onde a sabedoria ancestral encontra a precisão matemática do seu destino."
          </p>
        </motion.div>

        {step === 'form' ? (
          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8 }}
            className="max-w-md mx-auto bg-card/30 backdrop-blur-md border border-primary/20 p-8 rounded-xl shadow-[0_0_50px_rgba(0,0,0,0.5)] relative overflow-hidden"
          >
            {/* Decorative border glow */}
            <div className="absolute inset-0 bg-gradient-to-b from-primary/5 to-transparent pointer-events-none" />
            
            <form onSubmit={handleSubmit} className="space-y-8 relative z-10">
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="nome" className="font-cinzel text-primary text-lg">Seu Nome Completo</Label>
                  <Input 
                    id="nome" 
                    value={nome}
                    onChange={(e) => setNome(e.target.value)}
                    placeholder="Digite seu nome..."
                    className="bg-black/40 border-primary/30 focus:border-primary text-lg h-12 font-cormorant placeholder:text-muted-foreground/50"
                    required
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="nascimento" className="font-cinzel text-primary text-lg">Data de Nascimento</Label>
                  <Input 
                    id="nascimento" 
                    type="date"
                    value={dataNascimento}
                    onChange={(e) => setDataNascimento(e.target.value)}
                    className="bg-black/40 border-primary/30 focus:border-primary text-lg h-12 font-cormorant"
                    required
                  />
                </div>
              </div>

              <Button 
                type="submit" 
                disabled={loading}
                className="w-full h-14 text-lg font-cinzel font-bold bg-primary text-primary-foreground hover:bg-primary/90 transition-all duration-500 shadow-[0_0_20px_rgba(212,175,55,0.2)] hover:shadow-[0_0_30px_rgba(212,175,55,0.4)]"
              >
                {loading ? (
                  <span className="flex items-center gap-2">
                    <Sparkles className="animate-spin w-5 h-5" /> Revelando Destino...
                  </span>
                ) : (
                  <span className="flex items-center gap-2">
                    Revelar Meu Mapa <ArrowRight className="w-5 h-5" />
                  </span>
                )}
              </Button>
            </form>
          </motion.div>
        ) : mapa ? (
          <div className="space-y-12">
            
            {/* Download Button - Floating or Top */}
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="flex justify-end mb-4 sticky top-4 z-50 no-print"
            >
              <Button 
                onClick={() => downloadPdf('mapa-content', `Mapa_Prosperidade_${mapa.userData.nome.replace(/\s+/g, '_')}`)}
                disabled={isGenerating}
                className="bg-primary text-primary-foreground hover:bg-primary/90 shadow-[0_0_20px_rgba(212,175,55,0.3)] font-cinzel gap-2"
              >
                {isGenerating ? (
                  <Sparkles className="w-4 h-4 animate-spin" />
                ) : (
                  <Download className="w-4 h-4" />
                )}
                {isGenerating ? "Gerando PDF..." : "Baixar Mapa em PDF"}
              </Button>
            </motion.div>

            <div id="mapa-content" className="space-y-12 p-8 rounded-xl bg-black/20 backdrop-blur-sm">
            
            {/* 1. Capa Personalizada */}
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="text-center space-y-4 mb-12 py-12 border-y border-primary/20 bg-gradient-to-b from-transparent via-primary/5 to-transparent"
            >
              <h2 className="font-cinzel text-4xl text-primary tracking-widest">{mapa.userData.nome.toUpperCase()}</h2>
              <p className="font-cormorant text-2xl text-white/80 italic">
                {mapa.capa.SUBTITULO}
              </p>
              <div className="flex justify-center mt-6">
                <div className="w-16 h-16 border-2 border-primary rotate-45 flex items-center justify-center">
                  <div className="w-12 h-12 border border-primary/50 rotate-45"></div>
                </div>
              </div>
            </motion.div>

            {/* 2. Introdução */}
            <MysticCard 
              title={mapa.introducao.TITULO} 
              icon={<ScrollText className="w-6 h-6" />}
              delay={0.1}
              className="bg-black/40"
            >
              <p className="mb-4">{mapa.introducao.O_QUE_E}</p>
              <p className="mb-4"><strong className="text-primary">Como interpretar:</strong> {mapa.introducao.COMO_INTERPRETAR}</p>
              <p className="italic text-muted-foreground">"{mapa.introducao.PARA_QUE_SERVE}"</p>
            </MysticCard>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              
              {/* 3. Arquétipo */}
              <MysticCard 
                title={mapa.arquetipo.TITULO} 
                icon={<Crown className="w-6 h-6" />}
                delay={0.2}
                className="md:col-span-2 border-primary/40 bg-primary/5"
              >
                <p className="text-xl font-semibold mb-6 text-primary/90 leading-relaxed">{mapa.arquetipo.ESSENCIA}</p>
                
                <div className="grid md:grid-cols-2 gap-6 mb-6">
                  <div>
                    <strong className="block text-primary mb-2 font-cinzel border-b border-primary/20 pb-1">Forças Naturais</strong>
                    <p>{mapa.arquetipo.FORCAS}</p>
                  </div>
                  <div>
                    <strong className="block text-primary mb-2 font-cinzel border-b border-primary/20 pb-1">Padrão Recorrente</strong>
                    <p>{mapa.arquetipo.PADRAO}</p>
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-6 text-base">
                  <div className="bg-black/20 p-4 rounded border border-green-500/20">
                    <strong className="block text-green-400 mb-2 font-cinzel">Como o Dinheiro Flui</strong>
                    {mapa.arquetipo.FLUXO}
                  </div>
                  <div className="bg-black/20 p-4 rounded border border-red-500/20">
                    <strong className="block text-red-400 mb-2 font-cinzel">Onde se Perde</strong>
                    {mapa.arquetipo.PERDA}
                  </div>
                </div>
              </MysticCard>

              {/* 4. Bloqueios */}
              <MysticCard 
                title={`Bloqueio: ${mapa.bloqueio.TITULO}`} 
                icon={<Lock className="w-6 h-6" />}
                delay={0.3}
              >
                <p className="mb-4 text-lg">{mapa.bloqueio.MANIFESTACAO}</p>
                <div className="space-y-3 text-sm md:text-base">
                  <p><strong className="text-primary">Impacto Prático:</strong> {mapa.bloqueio.IMPACTO}</p>
                  <p><strong className="text-primary">Raiz Inconsciente:</strong> {mapa.bloqueio.RAIZ}</p>
                  <p className="italic text-muted-foreground border-l-2 border-primary/30 pl-3">{mapa.bloqueio.INTERFERENCIA}</p>
                </div>
              </MysticCard>

              {/* 5. Ciclo Atual */}
              <MysticCard 
                title={`Ciclo Atual: ${mapa.ciclo.TITULO}`} 
                icon={<Calendar className="w-6 h-6" />}
                delay={0.4}
              >
                <p className="mb-4 text-lg">{mapa.ciclo.MOMENTO}</p>
                <div className="space-y-3">
                  <p><strong className="text-primary">Oportunidade Oculta:</strong> {mapa.ciclo.OPORTUNIDADE}</p>
                  <div className="grid grid-cols-2 gap-4 mt-4">
                    <div className="bg-green-900/10 p-2 rounded border border-green-500/20">
                      <strong className="block text-green-400 text-xs font-cinzel mb-1">FAZER</strong>
                      <span className="text-sm">{mapa.ciclo.FAZER}</span>
                    </div>
                    <div className="bg-red-900/10 p-2 rounded border border-red-500/20">
                      <strong className="block text-red-400 text-xs font-cinzel mb-1">EVITAR</strong>
                      <span className="text-sm">{mapa.ciclo.EVITAR}</span>
                    </div>
                  </div>
                </div>
              </MysticCard>

              {/* 6. Mapa Temporal */}
              <MysticCard 
                title={mapa.periodo.TITULO} 
                icon={<Compass className="w-6 h-6" />}
                delay={0.5}
                className={
                  mapa.periodo.ID === 'PERIODO_ACAO' ? 'border-green-500/30 bg-green-900/5' :
                  mapa.periodo.ID === 'PERIODO_CAUTELA' ? 'border-red-500/30 bg-red-900/5' :
                  'border-blue-500/30 bg-blue-900/5'
                }
              >
                <p className="mb-4 text-lg font-medium">{mapa.periodo.VISAO}</p>
                <p className="mb-2"><strong className="text-primary">Meses Favoráveis:</strong> {mapa.periodo.MESES_FAVORAVEIS}</p>
                <p className="italic text-primary/80 border-t border-primary/10 pt-2 mt-2">"{mapa.periodo.USO_DO_TEMPO}"</p>
              </MysticCard>

              {/* 7. Direcionamento */}
              <MysticCard 
                title={`Direcionamento: ${mapa.direcionamento.TITULO}`} 
                icon={<Star className="w-6 h-6" />}
                delay={0.6}
              >
                <ul className="space-y-4">
                  <li className="flex flex-col">
                    <span className="text-primary font-bold text-sm font-cinzel">ONDE FOCAR</span>
                    <span className="text-lg">{mapa.direcionamento.FOCAR}</span>
                  </li>
                  <li className="flex flex-col">
                    <span className="text-primary font-bold text-sm font-cinzel">ATIVIDADES ALINHADAS</span>
                    <span>{mapa.direcionamento.ATIVIDADES}</span>
                  </li>
                  <li className="flex flex-col">
                    <span className="text-green-400 font-bold text-sm font-cinzel">FONTE DE RENDA</span>
                    <span>{mapa.direcionamento.RENDA}</span>
                  </li>
                  <li className="flex flex-col">
                    <span className="text-red-400 font-bold text-sm font-cinzel">O QUE DRENA</span>
                    <span>{mapa.direcionamento.DRENA}</span>
                  </li>
                </ul>
              </MysticCard>

              {/* 8. Código de Estabilidade */}
              <MysticCard 
                title={`Código: ${mapa.codigo.TITULO}`} 
                icon={<BookOpen className="w-6 h-6" />}
                delay={0.7}
                className="md:col-span-2 bg-gradient-to-r from-primary/10 via-transparent to-primary/10"
              >
                <div className="text-center space-y-6">
                  <p className="text-2xl font-cormorant italic text-white">"{mapa.codigo.PRINCIPIO}"</p>
                  
                  <div className="grid md:grid-cols-2 gap-8 text-left mt-6">
                    <div>
                      <strong className="block text-primary font-cinzel mb-2">Pilares do Equilíbrio</strong>
                      <p>{mapa.codigo.PILARES}</p>
                    </div>
                    <div>
                      <strong className="block text-primary font-cinzel mb-2">Como Manter</strong>
                      <p>{mapa.codigo.MANTER}</p>
                    </div>
                  </div>
                </div>
              </MysticCard>

              {/* 9. Ritual */}
              <MysticCard 
                title={mapa.ritual.TITULO} 
                icon={<Gem className="w-6 h-6" />}
                delay={0.8}
                className="md:col-span-2 border-primary/50 shadow-[0_0_30px_rgba(212,175,55,0.1)]"
              >
                <div className="text-center mb-8">
                  <p className="text-lg text-primary/90">{mapa.ritual.OBJETIVO}</p>
                </div>

                <div className="grid md:grid-cols-2 gap-8">
                  <div className="space-y-6">
                    <div className="bg-black/30 p-4 rounded border border-primary/20">
                      <strong className="block text-primary font-cinzel mb-2">Preparação</strong>
                      <p>{mapa.ritual.PREPARACAO}</p>
                    </div>
                    <div className="bg-black/30 p-4 rounded border border-primary/20">
                      <strong className="block text-primary font-cinzel mb-2">Passo a Passo</strong>
                      <p>{mapa.ritual.PASSO_A_PASSO}</p>
                    </div>
                  </div>
                  
                  <div className="flex flex-col justify-center items-center bg-primary/5 p-6 rounded-lg border border-primary/20">
                    <Heart className="w-8 h-8 text-primary mb-4 animate-pulse" />
                    <strong className="block text-primary font-cinzel mb-4 text-lg">Afirmação de Poder</strong>
                    <p className="text-2xl font-cormorant italic text-white text-center">"{mapa.ritual.AFIRMACAO}"</p>
                  </div>
                </div>
              </MysticCard>

              {/* 10. Mensagem Final */}
              <MysticCard 
                title={mapa.mensagemFinal.TITULO} 
                icon={<Lightbulb className="w-6 h-6" />}
                delay={0.9}
                className="md:col-span-2 bg-primary/10 border-primary/60"
              >
                <div className="space-y-4 text-center max-w-3xl mx-auto">
                  <p className="text-lg">{mapa.mensagemFinal.SINTESE}</p>
                  <p className="text-lg font-semibold text-primary">{mapa.mensagemFinal.DIRECIONAMENTO}</p>
                  <p className="italic text-muted-foreground">{mapa.mensagemFinal.INTEGRACAO}</p>
                </div>
              </MysticCard>

              {/* 11. Encerramento */}
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 1.0 }}
                className="md:col-span-2 text-center py-12 space-y-6"
              >
                <p className="text-xl font-cormorant italic text-white/60">"{mapa.encerramento.REFLEXAO}"</p>
                <h3 className="text-2xl md:text-3xl font-cinzel text-primary font-bold">{mapa.encerramento.FRASE}</h3>
                <p className="text-muted-foreground">{mapa.encerramento.CONVITE}</p>
              </motion.div>

            </div>
            </div> {/* End of mapa-content */}

            <div className="text-center pt-8 pb-20">
              <Button 
                onClick={resetForm}
                variant="outline"
                className="border-primary/50 text-primary hover:bg-primary hover:text-primary-foreground font-cinzel px-8 py-6 text-lg"
              >
                Gerar Novo Mapa
              </Button>
            </div>

          </div>
        ) : null}
      </main>
    </div>
  );
}
