import mapaDb from '../data/mapa_db.json';

// Tipos para os dados do mapa atualizados
export interface MapaData {
  capa: any;
  introducao: any;
  arquetipo: any;
  bloqueio: any;
  ciclo: any;
  periodo: any;
  direcionamento: any;
  codigo: any;
  ritual: any;
  mensagemFinal: any;
  encerramento: any;
  userData: {
    nome: string;
    dataNascimento: string;
    dia: number;
    mes: number;
    ano: number;
    anoAtual: number;
  };
}

// Função auxiliar SOMA(n)
function SOMA(n: number): number {
  return n.toString().split('').reduce((acc, digit) => acc + parseInt(digit), 0);
}

// Função auxiliar CALC_INDICE(valor, base)
function CALC_INDICE(valor: number, base: number): number {
  const resultado = valor % base;
  if (resultado === 0) {
    return base;
  }
  return resultado;
}

export function gerarMapaProsperidade(nome: string, dataNascimento: string): MapaData {
  // 1. Parse da data
  const [anoStr, mesStr, diaStr] = dataNascimento.split('-');
  const dia = parseInt(diaStr);
  const mes = parseInt(mesStr);
  const ano = parseInt(anoStr);
  const anoAtual = new Date().getFullYear();

  // 2. Cálculos por Sessão

  // SESSÃO 1 — CAPA (Fixo)
  const capa = mapaDb.sessoes.sessao_1[0];

  // SESSÃO 2 — INTRODUÇÃO (Fixo)
  const introducao = mapaDb.sessoes.sessao_2[0];

  // SESSÃO 3 — ARQUÉTIPO FINANCEIRO CENTRAL
  // Indice_Arquétipo = CALC_INDICE( D + M + SOMA(A), 12 )
  const indiceArquetipo = CALC_INDICE(dia + mes + SOMA(ano), 12);
  const arquetipo = mapaDb.sessoes.sessao_3.find((item: any) => item.id === `ARQUETIPO_${indiceArquetipo}`);

  // SESSÃO 4 — BLOQUEIOS ENERGÉTICOS DO DINHEIRO
  // Indice_Bloqueio = CALC_INDICE( M, 9 )
  const indiceBloqueio = CALC_INDICE(mes, 9);
  const bloqueio = mapaDb.sessoes.sessao_4.find((item: any) => item.id === `BLOQUEIO_${indiceBloqueio}`);

  // SESSÃO 5 — CICLO FINANCEIRO ATUAL
  // Indice_Ciclo = CALC_INDICE( D + M + C, 9 )
  const indiceCiclo = CALC_INDICE(dia + mes + anoAtual, 9);
  const ciclo = mapaDb.sessoes.sessao_5.find((item: any) => item.id === `CICLO_${indiceCiclo}`);

  // SESSÃO 6 — MAPA TEMPORAL DA PROSPERIDADE
  // Se Indice_Ciclo ∈ {1,2,3} → AÇÃO
  // Se Indice_Ciclo ∈ {4,5,6} → CAUTELA
  // Se Indice_Ciclo ∈ {7,8,9} → NEUTRO
  let periodoId = "PERIODO_NEUTRO";
  if ([1, 2, 3].includes(indiceCiclo)) periodoId = "PERIODO_ACAO";
  else if ([4, 5, 6].includes(indiceCiclo)) periodoId = "PERIODO_CAUTELA";
  
  const periodo = mapaDb.sessoes.sessao_6.find((item: any) => item.id === periodoId);

  // SESSÃO 7 — DIRECIONAMENTO DE PROSPERIDADE
  // Indice_Direcionamento = CALC_INDICE( D × SOMA(A), 9 )
  const indiceDirecionamento = CALC_INDICE(dia * SOMA(ano), 9);
  const direcionamento = mapaDb.sessoes.sessao_7.find((item: any) => item.id === `PERFIL_${indiceDirecionamento}`);

  // SESSÃO 8 — CÓDIGO DE ESTABILIDADE FINANCEIRA
  // Indice_Codigo = CALC_INDICE( Indice_Arquétipo + Indice_Ciclo, 6 )
  const indiceCodigo = CALC_INDICE(indiceArquetipo + indiceCiclo, 6);
  const codigo = mapaDb.sessoes.sessao_8.find((item: any) => item.id === `CODIGO_${indiceCodigo}`);

  // SESSÃO 9 — RITUAL SIMBÓLICO DE ALINHAMENTO
  // Indice_Ritual = CALC_INDICE( D + M, 6 )
  const indiceRitual = CALC_INDICE(dia + mes, 6);
  const ritual = mapaDb.sessoes.sessao_9.find((item: any) => item.id === `RITUAL_${indiceRitual}`);

  // SESSÃO 10 — MENSAGEM FINAL (Fixo)
  const mensagemFinal = mapaDb.sessoes.sessao_10[0];

  // SESSÃO 11 — ENCERRAMENTO (Fixo)
  const encerramento = mapaDb.sessoes.sessao_11[0];

  return {
    capa,
    introducao,
    arquetipo,
    bloqueio,
    ciclo,
    periodo,
    direcionamento,
    codigo,
    ritual,
    mensagemFinal,
    encerramento,
    userData: {
      nome,
      dataNascimento,
      dia,
      mes,
      ano,
      anoAtual
    }
  };
}
