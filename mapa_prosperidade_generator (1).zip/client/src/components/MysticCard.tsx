import { cn } from "@/lib/utils";
import { motion } from "framer-motion";
import { ReactNode } from "react";

interface MysticCardProps {
  title: string;
  children: ReactNode;
  className?: string;
  delay?: number;
  icon?: ReactNode;
}

export function MysticCard({ title, children, className, delay = 0, icon }: MysticCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.8, delay, ease: "easeOut" }}
      className={cn(
        "relative overflow-hidden rounded-lg border border-primary/20 bg-card/50 backdrop-blur-sm p-6 md:p-8",
        "hover:border-primary/40 transition-colors duration-500",
        "before:absolute before:top-0 before:left-0 before:w-full before:h-[1px] before:bg-gradient-to-r before:from-transparent before:via-primary/50 before:to-transparent",
        className
      )}
    >
      <div className="flex items-center gap-3 mb-4">
        {icon && <div className="text-primary">{icon}</div>}
        <h3 className="font-cinzel text-xl md:text-2xl text-primary font-bold tracking-wide">
          {title}
        </h3>
      </div>
      
      <div className="font-cormorant text-lg md:text-xl leading-relaxed text-foreground/90 space-y-4">
        {children}
      </div>
      
      {/* Decorative corner elements */}
      <div className="absolute top-2 right-2 w-2 h-2 border-t border-r border-primary/30" />
      <div className="absolute bottom-2 left-2 w-2 h-2 border-b border-l border-primary/30" />
    </motion.div>
  );
}
