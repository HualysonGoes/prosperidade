import html2canvas from 'html2canvas';
import jsPDF from 'jspdf';
import { useState } from 'react';
import { toast } from 'sonner';

export function usePdfDownload() {
  const [isGenerating, setIsGenerating] = useState(false);

  const downloadPdf = async (elementId: string, fileName: string) => {
    const element = document.getElementById(elementId);
    if (!element) {
      toast.error("Elemento do mapa não encontrado.");
      return;
    }

    setIsGenerating(true);
    const toastId = toast.loading("Gerando seu PDF mágico...");

    try {
      // Temporary style adjustments for better PDF rendering
      const originalStyle = element.style.cssText;
      element.style.backdropFilter = 'none';
      element.style.backgroundColor = '#0a0a0a'; // Solid dark background instead of transparent
      element.style.color = '#ffffff';
      
      // Create canvas from element
      const canvas = await html2canvas(element, {
        scale: 2, // Higher quality
        useCORS: true, // Allow loading cross-origin images
        logging: false,
        backgroundColor: '#050505', // Deep void background
        windowWidth: 1200, // Force desktop width for consistent layout
        ignoreElements: (element) => element.classList.contains('no-print'), // Ignore elements with no-print class
      });

      // Restore original styles
      element.style.cssText = originalStyle;

      const imgData = canvas.toDataURL('image/png');
      
      // Calculate PDF dimensions (A4)
      const pdf = new jsPDF({
        orientation: 'portrait',
        unit: 'mm',
        format: 'a4',
      });

      const imgWidth = 210; // A4 width in mm
      const pageHeight = 297; // A4 height in mm
      const imgHeight = (canvas.height * imgWidth) / canvas.width;
      
      let heightLeft = imgHeight;
      let position = 0;

      // Add first page
      pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight);
      heightLeft -= pageHeight;

      // Add subsequent pages if content is longer than one page
      while (heightLeft >= 0) {
        position = heightLeft - imgHeight;
        pdf.addPage();
        pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight);
        heightLeft -= pageHeight;
      }

      pdf.save(`${fileName}.pdf`);
      toast.success("PDF baixado com sucesso!", { id: toastId });
    } catch (error) {
      console.error('Error generating PDF:', error);
      toast.error("Erro ao gerar PDF. Tente novamente.", { id: toastId });
    } finally {
      setIsGenerating(false);
    }
  };

  return { downloadPdf, isGenerating };
}
